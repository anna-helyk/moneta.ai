import PlaceholderScreen from "@/components/placeholder-screen"

export default function LessonTwoPageUA() {
  return <PlaceholderScreen />
}
