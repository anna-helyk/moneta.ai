import PlaceholderScreen from "@/components/placeholder-screen"

export default function LessonQuizThreePageUA() {
  return <PlaceholderScreen />
}
