import PlaceholderScreen from "@/components/placeholder-screen"

export default function LessonQuizTwoPageUA() {
  return <PlaceholderScreen />
}
