import PlaceholderScreen from "@/components/placeholder-screen"

export default function LessonQuizResultThreePageUA() {
  return <PlaceholderScreen />
}
