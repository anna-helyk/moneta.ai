import PlaceholderScreen from "@/components/placeholder-screen"

export default function PlaceholderPageUA() {
  return <PlaceholderScreen />
}
