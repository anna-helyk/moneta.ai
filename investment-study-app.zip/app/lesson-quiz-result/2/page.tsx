import PlaceholderScreen from "@/components/placeholder-screen"

export default function LessonQuizResultTwoPage() {
  return <PlaceholderScreen />
}
