"use client"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"

interface PlaceholderScreenProps {
  backRoute?: string
}

export default function PlaceholderScreen({ backRoute }: PlaceholderScreenProps) {
  const router = useRouter()
  const [userCountry, setUserCountry] = useState<string>("us")

  useEffect(() => {
    // Check selected language
    const selectedLanguage = localStorage.getItem("selectedLanguage")
    if (selectedLanguage === "ua") {
      setUserCountry("ua")
    } else {
      setUserCountry("en")
    }
  }, [])

  const handleGoToProfile = () => {
    router.push(userCountry === "ua" ? "/ua/profile" : "/profile")
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#F5F5F5] p-6">
      <div className="relative max-w-sm w-full">
        {/* Shadow layer */}
        <div
          className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
          style={{ backgroundColor: "#303030" }}
        ></div>

        {/* Content layer */}
        <div className="relative bg-white rounded-2xl p-6 border border-gray-100 min-h-[500px] flex flex-col">
          <div className="flex-1 flex flex-col items-center justify-center space-y-6">
            {/* Emoji */}
            <div className="text-8xl">💅</div>

            {/* Text content */}
            <div className="text-center">
              <h1 className="text-2xl font-bold text-[#303030] mb-4">
                {userCountry === "ua" ? "Зараз трошки чілим і наводимо красу." : "BRB, doing a glow-up."}
              </h1>
              <p className="text-[#303030] text-base">
                {userCountry === "ua"
                  ? "Повернемося зовсім скоро, ще стильніші та швидші."
                  : "We're polishing up this part — it'll be back looking extra fresh soon!"}
              </p>
            </div>
          </div>

          {/* Button */}
          <Button
            onClick={handleGoToProfile}
            variant="outline"
            className="w-full border-gray-300 hover:bg-gray-50 text-gray-800 font-semibold py-3 rounded-lg flex items-center justify-center"
          >
            <Home size={18} className="mr-2" />
            {userCountry === "ua" ? "Профіль" : "Profile"}
          </Button>

          {/* Instagram icon */}
          <div className="flex justify-center mt-4">
            <div className="w-8 h-8 rounded-full border-2 border-gray-400 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                <path d="m16 11.37-4-4-4 4" />
                <path d="M12 3v14" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
