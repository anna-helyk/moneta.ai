"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

// Mock lesson content
const lessonContent = {
  "1": {
    title: "Why do you need to invest?",
    subtitle: "What type of investor are You?",
    classNumber: 1,
    content: [
      {
        type: "intro",
        content:
          "In this lesson, we'll explore why investing is important and help you discover your investor profile.",
      },
      {
        type: "test",
        questions: [
          {
            id: 1,
            question: "What are your expectations for your investment?",
            options: [
              {
                letter: "A",
                value: "preserve",
                label: "The most important thing for me is to preserve the value of my capital.",
                score: 0,
              },
              {
                letter: "B",
                value: "market",
                label: "I want to receive market returns on my invested capital.",
                score: 10,
              },
              {
                letter: "C",
                value: "high",
                label: "I want higher returns than the market and I am willing to take risks.",
                score: 15,
              },
            ],
          },
          {
            id: 2,
            question: "How do you feel about market fluctuations?",
            options: [
              {
                letter: "A",
                value: "avoid",
                label: "I want to avoid fluctuations",
                score: 0,
              },
              {
                letter: "B",
                value: "minor",
                label: "Minor fluctuations are acceptable",
                score: 15,
              },
              {
                letter: "C",
                value: "high",
                label: "High fluctuations are fine for my goals",
                score: 20,
              },
              {
                letter: "D",
                value: "losses",
                label: "I accept temporary losses",
                score: 30,
              },
            ],
          },
        ],
      },
    ],
  },
}

export default function LessonPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const lessonId = params.id
  const lesson = lessonContent[lessonId as keyof typeof lessonContent]
  const [showTest, setShowTest] = useState(false)

  if (!lesson) {
    return <div>Lesson not found</div>
  }

  const handleBack = () => {
    router.push("/lessons/1")
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5] p-6">
      <div className="space-y-6">
        {/* Back button */}
        <div>
          <button
            onClick={handleBack}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white"
          >
            <ArrowLeft size={18} />
          </button>
        </div>

        {/* Class Title Card */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex justify-between items-start">
              <h1 className="text-xl font-bold text-[#303030]">
                Class #{lesson.classNumber}: {lesson.title}
              </h1>
            </div>
          </div>
        </div>

        {/* Video Component */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative rounded-2xl border border-gray-100 overflow-hidden">
            <iframe
              src="https://www.youtube.com/embed/4cszZ8fgO2A"
              title="Why do you need to invest?"
              className="w-full aspect-video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              style={{ border: "none" }}
            />
          </div>
        </div>

        {/* Quiz Introduction */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-white rounded-2xl p-6 border border-gray-100">
            <h2 className="text-xl font-bold text-[#303030] mb-2">{lesson.subtitle}</h2>
            <p className="text-gray-600">below ↓</p>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={() => router.push(`/lesson-quiz/${lessonId}`)}
          className="w-full bg-[#D1F26E] hover:bg-[#D1F26E]/90 text-[#303030] font-medium py-3 rounded-lg flex items-center justify-center"
        >
          Start test
        </button>
      </div>
    </div>
  )
}
