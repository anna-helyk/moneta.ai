"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle, Lock, Circle } from "lucide-react"

// Mock data for the learning roadmap
const beginnerLessons = [
  { id: 1, title: "What is Investing?", completed: false, locked: false },
  { id: 2, title: "Understanding Risk Profiles", completed: false, locked: true },
  { id: 3, title: "Inflation Basics", completed: false, locked: true },
  { id: 4, title: "Compound Interest", completed: false, locked: true },
  { id: 5, title: "Types of Investments", completed: false, locked: true },
  { id: 6, title: "Beginner Confirmation Test", completed: false, locked: true, isTest: true },
]

export default function RoadmapPage() {
  const router = useRouter()
  const [lessons, setLessons] = useState(beginnerLessons)
  const [userLevel, setUserLevel] = useState("beginner")
  const [points, setPoints] = useState(0)

  useEffect(() => {
    // In a real app, we would fetch this from an API or state management
    const storedLevel = localStorage.getItem("userLevel") || "beginner"
    setUserLevel(storedLevel)

    // Check for completed lessons in localStorage
    const completedLessons = JSON.parse(localStorage.getItem("completedLessons") || "[]")

    if (completedLessons.length > 0) {
      const updatedLessons = lessons.map((lesson) => {
        // If this lesson is in the completed list
        if (completedLessons.includes(lesson.id)) {
          lesson.completed = true

          // Unlock the next lesson if it exists
          const nextIndex = lessons.findIndex((l) => l.id === lesson.id) + 1
          if (nextIndex < lessons.length) {
            lessons[nextIndex].locked = false
          }
        }
        return lesson
      })

      setLessons(updatedLessons)
      setPoints(completedLessons.length * 10) // 10 points per completed lesson
    }
  }, [])

  const handleLessonClick = (lesson: any) => {
    if (!lesson.locked) {
      router.push(`/lesson/${lesson.id}`)
    }
  }

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-purple-800">Learning Roadmap</h1>
        <div className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">{points} points</div>
      </div>

      <div className="bg-purple-50 rounded-xl p-4">
        <h2 className="font-medium text-purple-800 capitalize">{userLevel} Level</h2>
        <p className="text-sm text-gray-600 mt-1">
          Complete all lessons and pass the confirmation test to advance to the next level.
        </p>
      </div>

      <div className="space-y-3">
        {lessons.map((lesson, index) => (
          <Card
            key={lesson.id}
            className={`p-4 border-l-4 ${
              lesson.completed ? "border-l-green-500" : lesson.isTest ? "border-l-purple-600" : "border-l-gray-300"
            } ${lesson.locked ? "opacity-70" : "cursor-pointer hover:bg-gray-50"}`}
            onClick={() => handleLessonClick(lesson)}
          >
            <div className="flex items-center">
              <div className="mr-3">
                {lesson.completed ? (
                  <CheckCircle className="h-6 w-6 text-green-500" />
                ) : lesson.locked ? (
                  <Lock className="h-6 w-6 text-gray-400" />
                ) : (
                  <Circle className="h-6 w-6 text-purple-600" />
                )}
              </div>
              <div className="flex-1">
                <h3 className={`font-medium ${lesson.isTest ? "text-purple-700" : "text-gray-800"}`}>{lesson.title}</h3>
                {lesson.isTest ? (
                  <p className="text-xs text-purple-600">Confirmation test</p>
                ) : (
                  <p className="text-xs text-gray-500">Lesson {index + 1}</p>
                )}
              </div>
              {!lesson.locked && !lesson.completed && (
                <Button variant="ghost" size="sm" className="text-purple-600 hover:text-purple-800 hover:bg-purple-50">
                  Start
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
