"use client"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

// Mock lesson content
const lessonContent = {
  "1": {
    title: "Чому потрібно інвестувати?",
    subtitle: "Який тип інвестора ви?",
    classNumber: 1,
    content: [
      {
        type: "intro",
        content:
          "У цьому уроці ми дослідимо, чому інвестування важливе та допоможемо вам відкрити ваш інвестиційний профіль.",
      },
      {
        type: "test",
        questions: [
          {
            id: 1,
            question: "Які очікування маєте до вашого вкладу?",
            options: [
              {
                letter: "A",
                value: "preserve",
                label: "Найважливіше для мене зберегти вартість капіталу.",
                score: 0,
              },
              {
                letter: "B",
                value: "market",
                label: "Я хочу отримати ринкові відсотки на мій вкладений капітал.",
                score: 10,
              },
              {
                letter: "C",
                value: "high",
                label: "Я хочу більш високу дохідність, ніж на ринку і готовий ризикувати.",
                score: 15,
              },
            ],
          },
        ],
      },
    ],
  },
}

export default function LessonPageUA({ params }: { params: { id: string } }) {
  const router = useRouter()
  const lessonId = params.id
  const lesson = lessonContent[lessonId as keyof typeof lessonContent]

  if (!lesson) {
    return <div>Урок не знайдено</div>
  }

  const handleBack = () => {
    router.push("/ua/lessons/1")
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5] p-6">
      <div className="space-y-6">
        {/* Back button */}
        <div>
          <button
            onClick={handleBack}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white"
          >
            <ArrowLeft size={18} />
          </button>
        </div>

        {/* Class Title Card */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex justify-between items-start">
              <h1 className="text-xl font-bold text-[#303030]">
                Урок #{lesson.classNumber}: {lesson.title}
              </h1>
            </div>
          </div>
        </div>

        {/* Video Component */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative rounded-2xl border border-gray-100 overflow-hidden">
            <iframe
              src="https://www.youtube.com/embed/4cszZ8fgO2A"
              title="Чому потрібно інвестувати?"
              className="w-full aspect-video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              style={{ border: "none" }}
            />
          </div>
        </div>

        {/* Quiz Introduction */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-white rounded-2xl p-6 border border-gray-100">
            <h2 className="text-xl font-bold text-[#303030] mb-2">{lesson.subtitle}</h2>
            <p className="text-gray-600">тест нижче ↓</p>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={() => router.push(`/ua/lesson-quiz/${lessonId}`)}
          className="w-full bg-[#D1F26E] hover:bg-[#D1F26E]/90 text-[#303030] font-medium py-3 rounded-lg flex items-center justify-center"
        >
          Почати тест
        </button>
      </div>
    </div>
  )
}
