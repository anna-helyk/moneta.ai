"use client"

import { useSearchParams, useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

// Function to determine Ukrainian investor type based on score
const getInvestorTypeUA = (score: number) => {
  if (score < 25) return { type: "дуже консервативний", emoji: "🧘‍♂️", highlight: false }
  if (score < 49) return { type: "консервативний", emoji: "🚶‍♂️", highlight: false }
  if (score < 73) return { type: "помірний", emoji: "🏄‍♂️", highlight: false }
  return { type: "ризиковий", emoji: "🏄‍♂️", highlight: true }
}

export default function LessonQuizResultPageUA({ params }: { params: { id: string } }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const lessonId = params.id
  const score = Number.parseInt(searchParams.get("score") || "0")
  const investorType = getInvestorTypeUA(score)

  const handleBack = () => {
    router.push(`/ua/lesson/${lessonId}`)
  }

  const handleComplete = () => {
    router.push("/ua/profile")
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#F5F5F5] p-6">
      <div className="relative max-w-sm w-full">
        {/* Shadow layer */}
        <div
          className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
          style={{ backgroundColor: "#303030" }}
        ></div>

        {/* Content layer */}
        <div className="relative bg-white rounded-2xl p-6 border border-gray-100 min-h-[500px] flex flex-col">
          <div className="flex justify-between items-start mb-6">
            <button
              onClick={handleBack}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="px-3 py-1 bg-[#F5F5F5] rounded-full text-sm font-medium border border-gray-200 shadow-sm">
              Урок #1
            </div>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center space-y-6">
            <div className="text-6xl">{investorType.emoji}</div>
            <div className="text-center">
              <p className="text-xl font-bold text-[#303030]">
                Ви
                {investorType.highlight ? (
                  <span className="inline-block bg-[#D1F26E] px-2 mx-1">{investorType.type}</span>
                ) : (
                  <span className="mx-1">{investorType.type}</span>
                )}
                інвестор
                {investorType.type === "дуже консервативний" ? "" : "."}
              </p>
            </div>
          </div>

          <button
            onClick={handleComplete}
            className="w-full bg-[#D1F26E] hover:bg-[#D1F26E]/90 text-[#303030] font-medium py-3 rounded-lg flex items-center justify-center"
          >
            Завершити
          </button>
        </div>
      </div>
    </div>
  )
}
