"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowRight } from "lucide-react"

export default function WelcomePage() {
  const router = useRouter()
  const [showSplash, setShowSplash] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user has seen splash screen before
    const hasSeenSplash = localStorage.getItem("hasSeenSplash")
    const selectedLanguage = localStorage.getItem("selectedLanguage")

    if (!hasSeenSplash) {
      // Show splash screen for first time users
      setShowSplash(true)

      const timer = setTimeout(() => {
        setShowSplash(false)
        localStorage.setItem("hasSeenSplash", "true")

        // After splash, go to language selection
        router.push("/language-selection")
      }, 1500)

      return () => clearTimeout(timer)
    } else {
      // Skip splash for returning users
      setShowSplash(false)

      // Check language selection and redirect accordingly
      if (!selectedLanguage) {
        router.push("/language-selection")
      } else if (selectedLanguage === "ua") {
        router.push("/ua")
      } else {
        setIsLoading(false)
      }
    }
  }, [router])

  // Show splash screen
  if (showSplash) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#D1F26E] p-6">
        <div className="flex flex-col items-center space-y-3">
          {/* Logo Card */}
          <div className="relative">
            {/* Shadow layer */}
            <div
              className="absolute inset-0 rounded-2xl translate-x-[3px] translate-y-[3px]"
              style={{ backgroundColor: "#303030" }}
            ></div>

            {/* Content layer */}
            <div className="relative bg-white rounded-2xl p-8 border border-gray-100 w-24 h-24 flex items-center justify-center">
              <div className="text-4xl">💸</div>
            </div>
          </div>

          {/* App Name */}
          <h1 className="text-[#303030] font-medium text-lg">moneta.ai</h1>
        </div>
      </div>
    )
  }

  // Show loading state while checking language
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#F5F5F5]">
        <div className="text-[#303030]">Loading...</div>
      </div>
    )
  }

  // Show main welcome page
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#F5F5F5] p-6">
      <div className="relative max-w-sm w-full">
        {/* Shadow layer */}
        <div
          className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
          style={{ backgroundColor: "#303030" }}
        ></div>

        {/* Content layer */}
        <div className="relative bg-white rounded-2xl p-6 border border-gray-100 min-h-[500px] flex flex-col">
          <div className="flex-1 flex flex-col items-start justify-center space-y-8 py-16">
            {/* Emoji */}
            <div className="text-8xl mb-4">💸</div>

            {/* Text content */}
            <div className="text-left">
              <h1 className="text-2xl font-bold text-[#303030] mb-4">Your guide to financial literacy.</h1>
              <p className="text-[#303030] text-base">
                This app helps you learn about money, manage it better, and build smart financial habits.
              </p>
            </div>
          </div>

          {/* Button */}
          <button
            onClick={() => router.push("/questionnaire/1")}
            className="w-full bg-[#D1F26E] hover:bg-[#D1F26E]/90 text-[#303030] font-medium py-3 rounded-lg flex items-center justify-center"
          >
            <span>Get started</span>
            <ArrowRight size={18} className="ml-2" />
          </button>
        </div>
      </div>
    </div>
  )
}
