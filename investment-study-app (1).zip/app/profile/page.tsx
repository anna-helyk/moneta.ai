"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Edit, FileText } from "lucide-react"

type UserProfile = {
  name: string
  age: string
  country: string
  score: string
}

export default function ProfilePage() {
  const router = useRouter()
  const [profile, setProfile] = useState<UserProfile>({
    name: "",
    age: "",
    country: "",
    score: "Emerging learner",
  })

  useEffect(() => {
    // Load user answers from localStorage
    const savedAnswers = localStorage.getItem("userAnswers")
    if (savedAnswers) {
      const answers = JSON.parse(savedAnswers)

      // Extract profile information
      setProfile({
        name: answers[2] || "User",
        age: answers[3] || "25",
        country: answers[1] === "us" ? "United States" : answers[1] === "ua" ? "Ukraine" : "Other",
        score: "Emerging learner", // Default score
      })
    }
  }, [])

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5] p-6">
      <div className="space-y-6">
        {/* Profile Card */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white text-xl">
                😊
              </div>
              <button className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100">
                <Edit size={18} className="text-gray-600" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex">
                <div className="w-1/3 text-gray-500">Name</div>
                <div className="w-2/3 font-medium text-[#303030]">{profile.name}</div>
              </div>
              <div className="flex">
                <div className="w-1/3 text-gray-500">Age</div>
                <div className="w-2/3 font-medium text-[#303030]">{profile.age}</div>
              </div>
              <div className="flex">
                <div className="w-1/3 text-gray-500">Country</div>
                <div className="w-2/3 font-medium text-[#303030]">{profile.country}</div>
              </div>
              <div className="flex">
                <div className="w-1/3 text-gray-500">Level</div>
                <div className="w-2/3 font-medium text-[#303030]">{profile.score}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Active Plan Card */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative bg-[#FCFFF2] rounded-2xl p-6 border border-gray-100">
            <div className="flex items-start mb-4">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white mr-3">
                <FileText size={18} />
              </div>
              <div>
                <div className="text-sm font-medium text-[#303030]">Plan #2</div>
                <h2 className="text-xl font-bold text-[#303030]">Level up your investments</h2>
              </div>
            </div>

            <button
              onClick={() => router.push("/lessons/1")}
              className="w-full bg-[#D1F26E] hover:bg-[#D1F26E]/90 text-[#303030] font-medium py-3 rounded-lg flex items-center justify-center mt-4"
            >
              Start
            </button>
          </div>
        </div>

        {/* Inactive Plan Card */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl translate-x-[8px] translate-y-[8px]"
            style={{ backgroundColor: "#303030" }}
          ></div>
          <div className="relative rounded-2xl p-6 border border-gray-100" style={{ backgroundColor: "#E6E6E6" }}>
            <div className="flex items-start">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#303030] text-white mr-3">
                <FileText size={18} />
              </div>
              <div>
                <div className="text-sm font-medium text-[#303030]">Plan #1</div>
                <h2 className="text-xl font-bold text-[#303030]">Money foundations: your first steps</h2>
              </div>
            </div>

            <button
              disabled
              className="w-full bg-gray-300 text-gray-500 font-medium py-3 rounded-lg flex items-center justify-center mt-4 cursor-not-allowed"
            >
              Start
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
